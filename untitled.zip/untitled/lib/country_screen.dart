import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class CountrySelectionScreen extends StatefulWidget {
  const CountrySelectionScreen({Key? key}) : super(key: key);

  @override
  _CountrySelectionScreenState createState() => _CountrySelectionScreenState();
}

class _CountrySelectionScreenState extends State<CountrySelectionScreen> {
  final List<String> countries = [
    'United States',
    'China',
    'Japan',
    'Germany',
    'India',
    'United Kingdom',
    'France',
    'Russia',
    'Canada',
    'Italy',
    'Brazil',
    'Australia',
    'South Korea',
    'Mexico',
    'Spain',
    'Indonesia',
    'Saudi Arabia',
    'Netherlands',
    'Turkey',
    'Switzerland'
  ];

  String? selectedCountry;
  Map<String, dynamic>? countryData;

  Future<void> fetchCountryData(String country) async {
    final apiUrl = 'https://api.api-ninjas.com/v1/country?name=$country';
    final response = await http.get(
      Uri.parse(apiUrl),
      headers: {'X-Api-Key': 'yyom+PHRdXBJxuvuPhG9kg==DnKEusFyMRsqJCuR'}, // Replace with your actual API key
    );

    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      if (data.isNotEmpty) {
        setState(() {
          countryData = data[0]; // Get the first country's data
        });
      } else {
        setState(() {
          countryData = null; // No data found
        });
      }
    } else {
      setState(() {
        countryData = null; // Handle error case
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Select Country'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            DropdownButton<String>(
              hint: const Text('Select a country'),
              value: selectedCountry,
              onChanged: (String? newValue) {
                setState(() {
                  selectedCountry = newValue;
                  if (newValue != null) {
                    fetchCountryData(newValue);
                  }
                });
              },
              items: countries.map<DropdownMenuItem<String>>((String value) {
                return DropdownMenuItem<String>(
                  value: value,
                  child: Text(value),
                );
              }).toList(),
            ),
            const SizedBox(height: 20),
            if (countryData != null) ...[
              const Text('Country Details', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
              const SizedBox(height: 10),
              Text('Name: ${countryData!['name']}'),
              Text('Capital: ${countryData!['capital']}'),
              Text('Region: ${countryData!['region']}'),
              Text('Surface Area: ${countryData!['surface_area'].toString()} km²'),
              Text('Forested Area: ${countryData!['forested_area']}%'),
              Text('Currency: ${countryData!['currency']['name']} (${countryData!['currency']['code']})'),
              Text('Population: ${countryData!['population']}'),
              Text('GDP: \$${countryData!['gdp'].toString()}'),
              Text('GDP per Capita: \$${countryData!['gdp_per_capita']}'),
              Text('GDP Growth: ${countryData!['gdp_growth']}%'),
            ] else if (countryData == null && selectedCountry != null) ...[
              const Text('No data found for this country.'),
            ],
          ],
        ),
      ),
    );
  }
}
